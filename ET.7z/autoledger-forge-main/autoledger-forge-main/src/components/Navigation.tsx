import { NavLink } from "react-router-dom";
import { 
  Home, 
  Workflow, 
  FileText, 
  Search, 
  Settings, 
  HelpCircle 
} from "lucide-react";

const Navigation = () => {
  const navItems = [
    { name: "Home", icon: Home, path: "/" },
    { name: "Workflow", icon: Workflow, path: "/workflow" },
    { name: "Reports", icon: FileText, path: "/reports" },
    { name: "Search", icon: Search, path: "/search" },
    { name: "Settings", icon: Settings, path: "/settings" },
    { name: "Help", icon: HelpCircle, path: "/help" },
  ];

  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <nav className="h-[60px] bg-nav border-b border-nav-foreground/10 flex items-center justify-between px-6">
      {/* Navigation items */}
      <div className="flex items-center gap-8">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-2 px-3 py-2 text-sm font-medium transition-all rounded-lg ${
                isActive
                  ? "text-primary bg-background shadow-sm"
                  : "text-nav-foreground hover:text-primary hover:bg-nav-hover"
              }`
            }
          >
            <item.icon className="w-4 h-4" />
            {item.name}
          </NavLink>
        ))}
      </div>

      {/* Right section with date and time */}
      <div className="flex items-center gap-4 text-nav-foreground">
        <div className="text-sm">
          <span className="font-medium">Today:</span> {currentDate}
        </div>
        <div className="text-sm">
          GMT+3
        </div>
      </div>
    </nav>
  );
};

export default Navigation;