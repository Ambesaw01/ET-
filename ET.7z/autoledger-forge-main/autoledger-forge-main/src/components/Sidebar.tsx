import { useState } from "react";
import { NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  ChevronDown,
  ChevronRight,
  LayoutDashboard,
  ShoppingCart,
  Users,
  Package,
  CreditCard,
  DollarSign,
  Calculator,
  Workflow,
  FileText,
  Search,
  Settings,
  HelpCircle,
  Building2,
  User
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  user: {
    name: string;
    role: string;
  };
}

const Sidebar = ({ isOpen, user }: SidebarProps) => {
  const [expandedSections, setExpandedSections] = useState<string[]>([
    "dashboard", "sales", "clients"
  ]);

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const menuSections = [
    {
      id: "dashboard",
      title: "Dashboard",
      icon: LayoutDashboard,
      items: [
        { name: "Overview", path: "/" },
        { name: "Quick Actions", path: "/quick-actions" },
        { name: "Recent Activity", path: "/activity" }
      ]
    },
    {
      id: "sales",
      title: "Sales",
      icon: ShoppingCart,
      items: [
        { name: "Record Sales", path: "/sales/record" },
        { name: "View Sales", path: "/sales/view" },
        { name: "Sales Reports", path: "/sales/reports" },
        { name: "Customer Management", path: "/sales/customers" }
      ]
    },
    {
      id: "clients",
      title: "Clients",
      icon: Users,
      items: [
        { name: "Add Client", path: "/clients/add" },
        { name: "Client Directory", path: "/clients" },
        { name: "Statements", path: "/clients/statements" },
        { name: "Aging Reports", path: "/clients/aging" }
      ]
    },
    {
      id: "inventory",
      title: "Inventory",
      icon: Package,
      items: [
        { name: "Add Item", path: "/inventory/add" },
        { name: "Inventory Adjustment", path: "/inventory/adjust" },
        { name: "Stock Report", path: "/inventory/stock" },
        { name: "Valuation", path: "/inventory/valuation" }
      ]
    },
    {
      id: "purchases",
      title: "Purchases",
      icon: CreditCard,
      items: [
        { name: "Record Purchase", path: "/purchases/record" },
        { name: "Vendor Management", path: "/purchases/vendors" },
        { name: "Purchase Reports", path: "/purchases/reports" },
        { name: "Payments", path: "/purchases/payments" }
      ]
    },
    {
      id: "finance",
      title: "Finance",
      icon: DollarSign,
      items: [
        { name: "Income Tracking", path: "/finance/income" },
        { name: "Expense Management", path: "/finance/expenses" },
        { name: "P&L", path: "/finance/pnl" },
        { name: "Cash Flow", path: "/finance/cashflow" }
      ]
    },
    {
      id: "accounting",
      title: "Accounting",
      icon: Calculator,
      items: [
        { name: "Journal Entries", path: "/accounting/journal" },
        { name: "General Ledger", path: "/accounting/ledger" },
        { name: "Trial Balance", path: "/accounting/trial-balance" },
        { name: "Financial Statements", path: "/accounting/statements" }
      ]
    },
    {
      id: "workflow",
      title: "Workflow",
      icon: Workflow,
      items: [
        { name: "Pending", path: "/workflow/pending" },
        { name: "Assigned", path: "/workflow/assigned" },
        { name: "Completed", path: "/workflow/completed" },
        { name: "Rejected", path: "/workflow/rejected" },
        { name: "Reversed", path: "/workflow/reversed" }
      ]
    },
    {
      id: "reports",
      title: "Reports",
      icon: FileText,
      items: [
        { name: "Financial Reports", path: "/reports/financial" },
        { name: "Specific Reports", path: "/reports/specific" },
        { name: "System Reports", path: "/reports/system" }
      ]
    },
    {
      id: "search",
      title: "Search",
      icon: Search,
      items: [
        { name: "Global Search", path: "/search" },
        { name: "Recent Searches", path: "/search/recent" },
        { name: "Search Help", path: "/search/help" }
      ]
    },
    {
      id: "settings",
      title: "Settings",
      icon: Settings,
      items: [
        { name: "Company", path: "/settings/company" },
        { name: "User Management", path: "/settings/users" },
        { name: "Chart of Accounts", path: "/settings/chart" },
        { name: "Security", path: "/settings/security" },
        { name: "Formatting", path: "/settings/formatting" }
      ]
    },
    {
      id: "help",
      title: "Help",
      icon: HelpCircle,
      items: [
        { name: "Getting Started", path: "/help/start" },
        { name: "User Guide", path: "/help/guide" },
        { name: "Tutorials", path: "/help/tutorials" },
        { name: "Support", path: "/help/support" }
      ]
    }
  ];

  if (!isOpen) return null;

  return (
    <div className="w-[280px] bg-sidebar border-r border-sidebar-border h-full fixed left-0 top-[130px] z-10 shadow-lg">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-sidebar-border bg-primary">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-foreground rounded-full flex items-center justify-center">
            <Building2 className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-primary-foreground">EasyBooks</h3>
            <p className="text-xs text-primary-foreground/80">Accounting System</p>
          </div>
        </div>
        <div className="mt-3 p-2 bg-primary-foreground/10 rounded">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-primary-foreground" />
            <div>
              <p className="text-sm font-medium text-primary-foreground">{user.name}</p>
              <p className="text-xs text-primary-foreground/70">{user.role}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <ScrollArea className="flex-1 h-[calc(100vh-200px)]">
        <div className="p-2">
          {menuSections.map((section) => (
            <Collapsible
              key={section.id}
              open={expandedSections.includes(section.id)}
              onOpenChange={() => toggleSection(section.id)}
            >
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-between p-3 h-auto hover:bg-sidebar-hover"
                >
                  <div className="flex items-center gap-3">
                    <section.icon className="w-4 h-4" />
                    <span className="font-medium">{section.title}</span>
                  </div>
                  {expandedSections.includes(section.id) ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="ml-4">
                <div className="space-y-1 py-2">
                  {section.items.map((item) => (
                    <NavLink
                      key={item.path}
                      to={item.path}
                      className={({ isActive }) =>
                        `block p-2 text-sm rounded transition-colors ${
                          isActive
                            ? "bg-primary text-primary-foreground"
                            : "text-sidebar-foreground hover:bg-sidebar-hover"
                        }`
                      }
                    >
                      {item.name}
                    </NavLink>
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default Sidebar;