import { useState } from "react";
import { toast } from "sonner";
import TransactionForm from "@/components/TransactionForm";

const JournalEntry = () => {
  const handleSave = (data: any) => {
    console.log("Saving journal entry:", data);
    toast.success(`Journal entry ${data.reference} saved successfully!`, {
      description: "Transaction is pending approval by a checker."
    });
  };

  const handleCancel = () => {
    toast.info("Journal entry cancelled");
  };

  return (
    <div className="p-6">
      <TransactionForm 
        type="journal"
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </div>
  );
};

export default JournalEntry;