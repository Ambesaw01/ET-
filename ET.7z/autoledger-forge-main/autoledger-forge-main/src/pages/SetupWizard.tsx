import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Building2, 
  Calendar, 
  Shield, 
  Calculator, 
  CheckCircle,
  ChevronRight,
  ChevronLeft,
  Sparkles
} from "lucide-react";

interface SetupData {
  company: {
    name: string;
    address: string;
    phone: string;
    email: string;
    taxId: string;
    businessType: string;
  };
  fiscal: {
    accountingMethod: string;
    fiscalYearStart: string;
    fiscalYearEnd: string;
    firstMonth: string;
  };
  admin: {
    name: string;
    pin: string;
    confirmPin: string;
    securityQuestion1: string;
    answer1: string;
    securityQuestion2: string;
    answer2: string;
  };
  chartOfAccounts: {
    useDefault: boolean;
  };
}

interface SetupWizardProps {
  onComplete: (data: SetupData) => void;
}

const SetupWizard = ({ onComplete }: SetupWizardProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [setupData, setSetupData] = useState<SetupData>({
    company: {
      name: "",
      address: "",
      phone: "",
      email: "",
      taxId: "",
      businessType: ""
    },
    fiscal: {
      accountingMethod: "accrual",
      fiscalYearStart: "",
      fiscalYearEnd: "",
      firstMonth: "january"
    },
    admin: {
      name: "",
      pin: "",
      confirmPin: "",
      securityQuestion1: "",
      answer1: "",
      securityQuestion2: "",
      answer2: ""
    },
    chartOfAccounts: {
      useDefault: true
    }
  });

  const steps = [
    { title: "Welcome", icon: Sparkles },
    { title: "Company Info", icon: Building2 },
    { title: "Fiscal Year", icon: Calendar },
    { title: "Admin Setup", icon: Shield },
    { title: "Chart of Accounts", icon: Calculator },
    { title: "Complete", icon: CheckCircle }
  ];

  const securityQuestions = [
    "What was the name of your first pet?",
    "What is your mother's maiden name?",
    "What city were you born in?",
    "What was the name of your elementary school?",
    "What is your favorite color?",
    "What was your first car?",
    "What is your favorite food?",
    "What is the name of your best friend?",
    "What was your childhood nickname?",
    "What is your favorite movie?"
  ];

  const businessTypes = [
    "Sole Proprietorship",
    "Partnership", 
    "Corporation",
    "LLC",
    "Non-Profit",
    "Other"
  ];

  const months = [
    { value: "january", label: "January" },
    { value: "february", label: "February" },
    { value: "march", label: "March" },
    { value: "april", label: "April" },
    { value: "may", label: "May" },
    { value: "june", label: "June" },
    { value: "july", label: "July" },
    { value: "august", label: "August" },
    { value: "september", label: "September" },
    { value: "october", label: "October" },
    { value: "november", label: "November" },
    { value: "december", label: "December" }
  ];

  const updateCompanyData = (field: string, value: string) => {
    setSetupData(prev => ({
      ...prev,
      company: { ...prev.company, [field]: value }
    }));
  };

  const updateFiscalData = (field: string, value: string) => {
    setSetupData(prev => ({
      ...prev,
      fiscal: { ...prev.fiscal, [field]: value }
    }));
  };

  const updateAdminData = (field: string, value: string) => {
    setSetupData(prev => ({
      ...prev,
      admin: { ...prev.admin, [field]: value }
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 0: return true; // Welcome
      case 1: return setupData.company.name && setupData.company.email; // Company
      case 2: return setupData.fiscal.fiscalYearStart && setupData.fiscal.fiscalYearEnd; // Fiscal
      case 3: return setupData.admin.name && setupData.admin.pin && setupData.admin.pin === setupData.admin.confirmPin && 
                     setupData.admin.securityQuestion1 && setupData.admin.answer1 && 
                     setupData.admin.securityQuestion2 && setupData.admin.answer2; // Admin
      case 4: return true; // Chart of Accounts
      default: return false;
    }
  };

  const validatePin = (pin: string) => {
    if (pin.length !== 4) return false;
    if (!/^\d{4}$/.test(pin)) return false;
    // Check for sequences and repeats
    const sequence1 = ['0123', '1234', '2345', '3456', '4567', '5678', '6789'];
    const sequence2 = ['9876', '8765', '7654', '6543', '5432', '3210', '2109', '1098'];
    if (sequence1.includes(pin) || sequence2.includes(pin)) return false;
    if (pin === pin[0].repeat(4)) return false; // All same digits
    return true;
  };

  const isPinValid = validatePin(setupData.admin.pin);
  const pinsMatch = setupData.admin.pin === setupData.admin.confirmPin;

  const renderWelcome = () => (
    <div className="text-center space-y-6">
      <div className="w-20 h-20 bg-gradient-to-br from-primary to-primary-light rounded-full flex items-center justify-center mx-auto">
        <Building2 className="w-10 h-10 text-primary-foreground" />
      </div>
      <div>
        <h2 className="text-3xl font-bold text-foreground mb-4">Welcome to EasyBooks Accounting</h2>
        <p className="text-lg text-muted-foreground mb-6">
          Let's set up your accounting system in just a few simple steps.
        </p>
        <div className="bg-muted/50 rounded-lg p-4 text-left">
          <h3 className="font-semibold mb-2">What we'll configure:</h3>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>• Company information and settings</li>
            <li>• Fiscal year and accounting preferences</li>
            <li>• Default administrator account</li>
            <li>• Chart of accounts structure</li>
          </ul>
        </div>
      </div>
    </div>
  );

  const renderCompanyInfo = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">Company Information</h2>
        <p className="text-muted-foreground">Tell us about your business</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2 space-y-2">
          <Label htmlFor="company-name">Company Name *</Label>
          <Input
            id="company-name"
            placeholder="Your Company Name"
            value={setupData.company.name}
            onChange={(e) => updateCompanyData("name", e.target.value)}
          />
        </div>
        
        <div className="md:col-span-2 space-y-2">
          <Label htmlFor="address">Business Address</Label>
          <Textarea
            id="address"
            placeholder="Street Address, City, State, ZIP"
            value={setupData.company.address}
            onChange={(e) => updateCompanyData("address", e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            placeholder="(555) 123-4567"
            value={setupData.company.phone}
            onChange={(e) => updateCompanyData("phone", e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="email">Email Address *</Label>
          <Input
            id="email"
            type="email"
            placeholder="contact@company.com"
            value={setupData.company.email}
            onChange={(e) => updateCompanyData("email", e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="tax-id">Tax ID / VAT Number</Label>
          <Input
            id="tax-id"
            placeholder="12-3456789"
            value={setupData.company.taxId}
            onChange={(e) => updateCompanyData("taxId", e.target.value)}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="business-type">Business Type</Label>
          <Select value={setupData.company.businessType} onValueChange={(value) => updateCompanyData("businessType", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select business type" />
            </SelectTrigger>
            <SelectContent>
              {businessTypes.map((type) => (
                <SelectItem key={type} value={type.toLowerCase().replace(/\s+/g, '-')}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );

  const renderFiscalYear = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">Fiscal Year Settings</h2>
        <p className="text-muted-foreground">Configure your accounting periods</p>
      </div>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Accounting Method</Label>
          <div className="grid grid-cols-2 gap-4">
            <Card 
              className={`cursor-pointer transition-all ${setupData.fiscal.accountingMethod === 'cash' ? 'ring-2 ring-primary bg-primary/5' : ''}`}
              onClick={() => updateFiscalData("accountingMethod", "cash")}
            >
              <CardContent className="p-4 text-center">
                <h3 className="font-semibold">Cash Basis</h3>
                <p className="text-sm text-muted-foreground">Record transactions when money changes hands</p>
              </CardContent>
            </Card>
            <Card 
              className={`cursor-pointer transition-all ${setupData.fiscal.accountingMethod === 'accrual' ? 'ring-2 ring-primary bg-primary/5' : ''}`}
              onClick={() => updateFiscalData("accountingMethod", "accrual")}
            >
              <CardContent className="p-4 text-center">
                <h3 className="font-semibold">Accrual Basis</h3>
                <p className="text-sm text-muted-foreground">Record transactions when they occur</p>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="fiscal-start">Fiscal Year Start Date *</Label>
            <Input
              id="fiscal-start"
              type="date"
              value={setupData.fiscal.fiscalYearStart}
              onChange={(e) => {
                updateFiscalData("fiscalYearStart", e.target.value);
                // Auto-calculate end date (365 days later)
                const startDate = new Date(e.target.value);
                const endDate = new Date(startDate);
                endDate.setFullYear(endDate.getFullYear() + 1);
                endDate.setDate(endDate.getDate() - 1);
                updateFiscalData("fiscalYearEnd", endDate.toISOString().split('T')[0]);
              }}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="fiscal-end">Fiscal Year End Date *</Label>
            <Input
              id="fiscal-end"
              type="date"
              value={setupData.fiscal.fiscalYearEnd}
              onChange={(e) => updateFiscalData("fiscalYearEnd", e.target.value)}
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="first-month">First Month of Financial Year</Label>
          <Select value={setupData.fiscal.firstMonth} onValueChange={(value) => updateFiscalData("firstMonth", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select first month" />
            </SelectTrigger>
            <SelectContent>
              {months.map((month) => (
                <SelectItem key={month.value} value={month.value}>
                  {month.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );

  const renderAdminSetup = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">Default Admin Setup</h2>
        <p className="text-muted-foreground">Create the system administrator account</p>
      </div>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="admin-name">Administrator Name *</Label>
          <Input
            id="admin-name"
            placeholder="Full Name"
            value={setupData.admin.name}
            onChange={(e) => updateAdminData("name", e.target.value)}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="admin-pin">4-Digit PIN *</Label>
            <Input
              id="admin-pin"
              type="password"
              placeholder="Enter 4-digit PIN"
              maxLength={4}
              value={setupData.admin.pin}
              onChange={(e) => updateAdminData("pin", e.target.value)}
            />
            {setupData.admin.pin && !isPinValid && (
              <p className="text-sm text-destructive">PIN must be 4 digits, no sequences or repeating numbers</p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="confirm-pin">Confirm PIN *</Label>
            <Input
              id="confirm-pin"
              type="password"
              placeholder="Confirm PIN"
              maxLength={4}
              value={setupData.admin.confirmPin}
              onChange={(e) => updateAdminData("confirmPin", e.target.value)}
            />
            {setupData.admin.confirmPin && !pinsMatch && (
              <p className="text-sm text-destructive">PINs do not match</p>
            )}
          </div>
        </div>
        
        <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
          <h3 className="font-semibold">Security Questions</h3>
          
          <div className="space-y-2">
            <Label htmlFor="security-q1">Security Question 1 *</Label>
            <Select value={setupData.admin.securityQuestion1} onValueChange={(value) => updateAdminData("securityQuestion1", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a security question" />
              </SelectTrigger>
              <SelectContent>
                {securityQuestions.map((question, index) => (
                  <SelectItem key={index} value={question}>
                    {question}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="answer1">Answer 1 *</Label>
            <Input
              id="answer1"
              placeholder="Your answer"
              value={setupData.admin.answer1}
              onChange={(e) => updateAdminData("answer1", e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="security-q2">Security Question 2 *</Label>
            <Select value={setupData.admin.securityQuestion2} onValueChange={(value) => updateAdminData("securityQuestion2", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select a different security question" />
              </SelectTrigger>
              <SelectContent>
                {securityQuestions
                  .filter(q => q !== setupData.admin.securityQuestion1)
                  .map((question, index) => (
                    <SelectItem key={index} value={question}>
                      {question}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="answer2">Answer 2 *</Label>
            <Input
              id="answer2"
              placeholder="Your answer"
              value={setupData.admin.answer2}
              onChange={(e) => updateAdminData("answer2", e.target.value)}
            />
          </div>
        </div>
      </div>
    </div>
  );

  const renderChartOfAccounts = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">Chart of Accounts Setup</h2>
        <p className="text-muted-foreground">Choose your account structure</p>
      </div>
      
      <div className="space-y-4">
        <Card 
          className={`cursor-pointer transition-all ${setupData.chartOfAccounts.useDefault ? 'ring-2 ring-primary bg-primary/5' : ''}`}
          onClick={() => setSetupData(prev => ({ ...prev, chartOfAccounts: { useDefault: true } }))}
        >
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-success" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg mb-2">Use Default Chart of Accounts (Recommended)</h3>
                <p className="text-muted-foreground mb-3">
                  Start with a comprehensive, industry-standard chart of accounts that includes:
                </p>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>• Current Assets (Cash, Receivables, Inventory)</div>
                  <div>• Fixed Assets (Equipment, Buildings)</div>
                  <div>• Current Liabilities (Payables, Accrued)</div>
                  <div>• Long-term Liabilities (Loans, Mortgages)</div>
                  <div>• Owner's Equity (Capital, Retained Earnings)</div>
                  <div>• Revenue Accounts (Sales, Service Income)</div>
                  <div>• Operating Expenses (Salaries, Rent, Utilities)</div>
                  <div>• Other Income/Expenses</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card 
          className={`cursor-pointer transition-all ${!setupData.chartOfAccounts.useDefault ? 'ring-2 ring-primary bg-primary/5' : ''}`}
          onClick={() => setSetupData(prev => ({ ...prev, chartOfAccounts: { useDefault: false } }))}
        >
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <Calculator className="w-6 h-6 text-warning" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg mb-2">Import Custom Chart of Accounts</h3>
                <p className="text-muted-foreground">
                  Upload your existing chart of accounts from a CSV file or set up accounts manually after initial setup.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderComplete = () => (
    <div className="text-center space-y-6">
      <div className="w-20 h-20 bg-gradient-to-br from-success to-success-light rounded-full flex items-center justify-center mx-auto">
        <CheckCircle className="w-10 h-10 text-success-foreground" />
      </div>
      <div>
        <h2 className="text-3xl font-bold text-foreground mb-4">Setup Complete!</h2>
        <p className="text-lg text-muted-foreground mb-6">
          Your EasyBooks Accounting system is ready to use.
        </p>
        
        <div className="bg-muted/50 rounded-lg p-6 text-left max-w-md mx-auto">
          <h3 className="font-semibold mb-4">Setup Summary:</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Company:</span>
              <span className="font-medium">{setupData.company.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Accounting Method:</span>
              <span className="font-medium capitalize">{setupData.fiscal.accountingMethod}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Fiscal Year:</span>
              <span className="font-medium">{setupData.fiscal.fiscalYearStart} to {setupData.fiscal.fiscalYearEnd}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Administrator:</span>
              <span className="font-medium">{setupData.admin.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Chart of Accounts:</span>
              <span className="font-medium">{setupData.chartOfAccounts.useDefault ? "Default" : "Custom"}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 0: return renderWelcome();
      case 1: return renderCompanyInfo();
      case 2: return renderFiscalYear();
      case 3: return renderAdminSetup();
      case 4: return renderChartOfAccounts();
      case 5: return renderComplete();
      default: return renderWelcome();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl shadow-xl">
        <CardHeader className="bg-gradient-to-r from-primary to-primary-light text-primary-foreground">
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl">EasyBooks Setup Wizard</CardTitle>
            <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground">
              Step {currentStep + 1} of {steps.length}
            </Badge>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-4">
            <Progress value={(currentStep / (steps.length - 1)) * 100} className="w-full" />
            <div className="flex justify-between mt-2 text-sm">
              {steps.map((step, index) => (
                <div key={index} className={`flex items-center gap-1 ${index <= currentStep ? 'text-primary-foreground' : 'text-primary-foreground/60'}`}>
                  <step.icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{step.title}</span>
                </div>
              ))}
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-8">
          {renderCurrentStep()}
        </CardContent>

        {/* Navigation */}
        <div className="flex justify-between p-6 border-t bg-muted/30">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 0}
            className="flex items-center gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </Button>
          
          {currentStep < steps.length - 1 ? (
            <Button
              onClick={nextStep}
              disabled={!canProceed()}
              className="flex items-center gap-2 bg-primary hover:bg-primary-hover"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button
              onClick={() => onComplete(setupData)}
              className="flex items-center gap-2 bg-success hover:bg-success-light"
            >
              <CheckCircle className="w-4 h-4" />
              Start Using EasyBooks
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
};

export default SetupWizard;