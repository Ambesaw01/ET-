import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Header from "@/components/Header";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import Dashboard from "./Dashboard";
import Reports from "./Reports";
import ChartOfAccounts from "./ChartOfAccounts";
import JournalEntry from "./JournalEntry";

interface User {
  name: string;
  role: string;
  type: "user" | "admin" | "custom-admin";
}

interface AccountingAppProps {
  user: User;
  onLogout: () => void;
}

const AccountingApp = ({ user, onLogout }: AccountingAppProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={toggleSidebar}
        user={user}
        onLogout={onLogout}
      />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} user={user} />
      
      {/* Main Content */}
      <main className={`transition-all duration-300 ${
        sidebarOpen ? 'ml-[280px]' : 'ml-0'
      } pt-0`}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/reports/*" element={<Reports />} />
          <Route path="/settings/chart" element={<ChartOfAccounts />} />
          <Route path="/accounting/journal" element={<JournalEntry />} />
          {/* Add more routes as components are created */}
        </Routes>
      </main>
      
      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-5 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default AccountingApp;