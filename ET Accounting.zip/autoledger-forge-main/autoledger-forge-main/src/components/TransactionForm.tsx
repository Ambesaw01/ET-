import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar, Calculator, Save, X, Search } from "lucide-react";

interface TransactionEntry {
  account: string;
  accountName: string;
  debit: string;
  credit: string;
}

interface TransactionFormProps {
  type: "journal" | "sales" | "purchase";
  onSave?: (data: any) => void;
  onCancel?: () => void;
}

const TransactionForm = ({ type, onSave, onCancel }: TransactionFormProps) => {
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    reference: "",
    description: "",
    entries: [
      { account: "", accountName: "", debit: "", credit: "" },
      { account: "", accountName: "", debit: "", credit: "" }
    ] as TransactionEntry[]
  });

  const [totals, setTotals] = useState({ debit: 0, credit: 0 });

  // Generate reference number
  const generateReference = () => {
    const prefixes = { journal: "JRN", sales: "SAL", purchase: "PUR" };
    const prefix = prefixes[type];
    const date = new Date().toISOString().slice(2, 10).replace(/-/g, '');
    const sequence = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
    return `${prefix}${sequence}-${date}`;
  };

  // Calculate totals
  const calculateTotals = (entries: TransactionEntry[]) => {
    const debitTotal = entries.reduce((sum, entry) => sum + (parseFloat(entry.debit) || 0), 0);
    const creditTotal = entries.reduce((sum, entry) => sum + (parseFloat(entry.credit) || 0), 0);
    setTotals({ debit: debitTotal, credit: creditTotal });
  };

  const updateEntry = (index: number, field: string, value: string) => {
    const newEntries = [...formData.entries];
    newEntries[index] = { ...newEntries[index], [field]: value };
    setFormData({ ...formData, entries: newEntries });
    calculateTotals(newEntries);
  };

  const addEntry = () => {
    setFormData({
      ...formData,
      entries: [...formData.entries, { account: "", accountName: "", debit: "", credit: "" }]
    });
  };

  const removeEntry = (index: number) => {
    if (formData.entries.length > 2) {
      const newEntries = formData.entries.filter((_, i) => i !== index);
      setFormData({ ...formData, entries: newEntries });
      calculateTotals(newEntries);
    }
  };

  const isBalanced = totals.debit === totals.credit && totals.debit > 0;

  const handleSave = () => {
    if (isBalanced && onSave) {
      onSave({
        ...formData,
        reference: formData.reference || generateReference(),
        totals
      });
    }
  };

  const typeLabels = {
    journal: "Journal Entry",
    sales: "Sales Transaction",
    purchase: "Purchase Transaction"
  };

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-lg">
      <CardHeader className="bg-primary text-primary-foreground">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            {typeLabels[type]}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span className="text-sm">{formData.date}</span>
            <Button variant="ghost" size="icon" onClick={onCancel}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-6 space-y-6">
        {/* Transaction Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="date">Transaction Date</Label>
            <Input
              id="date"
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="reference">Reference Number</Label>
            <Input
              id="reference"
              placeholder="Auto-generated if empty"
              value={formData.reference}
              onChange={(e) => setFormData({ ...formData, reference: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Enter transaction description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          />
        </div>

        {/* Transaction Entries */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Transaction Entries</h3>
            <Badge variant={isBalanced ? "default" : "destructive"}>
              Balance: {isBalanced ? "Balanced" : "Not Balanced"}
            </Badge>
          </div>

          {/* Header */}
          <div className="grid grid-cols-12 gap-2 p-3 bg-muted rounded-lg font-medium text-sm">
            <div className="col-span-3">Account</div>
            <div className="col-span-4">Account Name</div>
            <div className="col-span-2 text-right">Debit</div>
            <div className="col-span-2 text-right">Credit</div>
            <div className="col-span-1"></div>
          </div>

          {/* Entries */}
          <div className="space-y-2">
            {formData.entries.map((entry, index) => (
              <div key={index} className="grid grid-cols-12 gap-2 p-3 border rounded-lg">
                <div className="col-span-3">
                  <div className="flex gap-1">
                    <Input
                      placeholder="Account #"
                      value={entry.account}
                      onChange={(e) => updateEntry(index, "account", e.target.value)}
                    />
                    <Button variant="outline" size="icon">
                      <Search className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="col-span-4">
                  <Input
                    placeholder="Account Name"
                    value={entry.accountName}
                    onChange={(e) => updateEntry(index, "accountName", e.target.value)}
                  />
                </div>
                <div className="col-span-2">
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={entry.debit}
                    onChange={(e) => updateEntry(index, "debit", e.target.value)}
                    className="text-right"
                  />
                </div>
                <div className="col-span-2">
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={entry.credit}
                    onChange={(e) => updateEntry(index, "credit", e.target.value)}
                    className="text-right"
                  />
                </div>
                <div className="col-span-1">
                  {formData.entries.length > 2 && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeEntry(index)}
                      className="text-destructive hover:text-destructive"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Totals */}
          <div className="grid grid-cols-12 gap-2 p-3 bg-muted rounded-lg font-semibold">
            <div className="col-span-7">TOTALS:</div>
            <div className="col-span-2 text-right">${totals.debit.toFixed(2)}</div>
            <div className="col-span-2 text-right">${totals.credit.toFixed(2)}</div>
            <div className="col-span-1"></div>
          </div>

          <Button variant="outline" onClick={addEntry} className="w-full">
            Add Entry Line
          </Button>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={!isBalanced}
            className="bg-success hover:bg-success-light"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Transaction
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default TransactionForm;