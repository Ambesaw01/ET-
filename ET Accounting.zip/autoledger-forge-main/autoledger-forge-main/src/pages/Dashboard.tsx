import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PlusCircle,
  ShoppingCart,
  CreditCard,
  Package,
  Calculator,
  FileText,
  Workflow,
  Users,
  AlertCircle
} from "lucide-react";

const Dashboard = () => {
  // Sample financial data
  const financialMetrics = [
    {
      title: "Total Income",
      value: "$45,231.45",
      change: "+12.5%",
      trend: "up",
      icon: TrendingUp,
      color: "text-income"
    },
    {
      title: "Total Expenses",
      value: "$32,456.78",
      change: "+5.2%",
      trend: "up",
      icon: TrendingDown,
      color: "text-expense"
    },
    {
      title: "Net Profit",
      value: "$12,774.67",
      change: "+18.3%",
      trend: "up",
      icon: DollarSign,
      color: "text-profit"
    },
    {
      title: "Cash Flow",
      value: "$8,945.32",
      change: "-2.1%",
      trend: "down",
      icon: TrendingUp,
      color: "text-primary"
    }
  ];

  const quickActions = [
    { name: "Record Sales", icon: ShoppingCart, path: "/sales/record", color: "bg-success" },
    { name: "Record Purchase", icon: CreditCard, path: "/purchases/record", color: "bg-primary" },
    { name: "Inventory Adjustment", icon: Package, path: "/inventory/adjust", color: "bg-warning" },
    { name: "Journal Entry", icon: Calculator, path: "/accounting/journal", color: "bg-secondary" },
    { name: "Make Payment", icon: DollarSign, path: "/payments/make", color: "bg-profit" },
    { name: "Add Expense", icon: TrendingDown, path: "/expenses/add", color: "bg-expense" },
    { name: "Generate Report", icon: FileText, path: "/reports", color: "bg-muted" },
    { name: "View Workflow", icon: Workflow, path: "/workflow", color: "bg-nav" }
  ];

  const recentActivity = [
    { 
      id: "SAL0042-240101", 
      description: "Sales transaction recorded", 
      amount: "$1,250.00", 
      status: "approved",
      time: "2 hours ago"
    },
    { 
      id: "PUR0018-240101", 
      description: "Purchase order created", 
      amount: "$875.50", 
      status: "pending",
      time: "4 hours ago"
    },
    { 
      id: "JRN1087-240101", 
      description: "Journal entry posted", 
      amount: "$2,100.00", 
      status: "approved",
      time: "6 hours ago"
    },
    { 
      id: "INV0001-240101", 
      description: "Inventory adjustment", 
      amount: "$345.25", 
      status: "pending",
      time: "1 day ago"
    }
  ];

  const alerts = [
    { message: "5 transactions pending approval", type: "warning" },
    { message: "Low stock alert: Office Supplies", type: "info" },
    { message: "Password expires in 3 days", type: "warning" }
  ];

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      approved: "bg-success text-success-foreground",
      pending: "bg-warning text-warning-foreground",
      rejected: "bg-destructive text-destructive-foreground"
    };
    return variants[status] || "bg-muted text-muted-foreground";
  };

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's your financial overview.</p>
      </div>

      {/* Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {financialMetrics.map((metric, index) => (
          <Card key={index} className="shadow-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <h3 className="text-2xl font-bold">{metric.value}</h3>
                    <span className={`text-sm ${metric.trend === 'up' ? 'text-success' : 'text-destructive'}`}>
                      {metric.change}
                    </span>
                  </div>
                </div>
                <div className={`p-3 rounded-full bg-muted ${metric.color}`}>
                  <metric.icon className="w-6 h-6" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                variant="outline"
                className="h-20 flex flex-col items-center gap-2 hover:shadow-md transition-all"
              >
                <div className={`p-2 rounded ${action.color}`}>
                  <action.icon className="w-5 h-5 text-white" />
                </div>
                <span className="text-xs text-center">{action.name}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <Card className="lg:col-span-2 shadow-card">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <code className="text-sm font-mono text-primary">{activity.id}</code>
                      <Badge className={getStatusBadge(activity.status)}>
                        {activity.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{activity.description}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{activity.amount}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Alerts & Notifications */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              System Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {alerts.map((alert, index) => (
                <div key={index} className={`p-3 rounded-lg border-l-4 ${
                  alert.type === 'warning' ? 'border-warning bg-warning/10' : 'border-primary bg-primary/10'
                }`}>
                  <p className="text-sm">{alert.message}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Income vs Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-muted/30 rounded-lg flex items-center justify-center">
              <p className="text-muted-foreground">Chart visualization would go here</p>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Monthly Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-muted/30 rounded-lg flex items-center justify-center">
              <p className="text-muted-foreground">Bar chart would go here</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;