import { useState } from "react";
import Login from "./Login";
import AccountingApp from "./AccountingApp";
import SetupWizard from "./SetupWizard";

interface User {
  name: string;
  role: string;
  type: "user" | "admin" | "custom-admin";
}

interface SetupData {
  company: any;
  fiscal: any;
  admin: any;
  chartOfAccounts: any;
}

const Index = () => {
  const [setupCompleted, setSetupCompleted] = useState(false); // In real app, check if admin account exists
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const handleSetupComplete = (setupData: SetupData) => {
    console.log("Setup completed with data:", setupData);
    // In a real app, this would save the setup data to the database
    // and create the admin account, company settings, chart of accounts, etc.
    setSetupCompleted(true);
  };

  const handleLogin = (type: "user" | "admin" | "custom-admin", credentials: any) => {
    // Simulate authentication
    let userData: User;
    
    switch (type) {
      case "admin":
        userData = { name: "Default Admin", role: "System Administrator", type: "admin" };
        break;
      case "custom-admin":
        userData = { name: credentials.username || "Custom Admin", role: "Administrator", type: "custom-admin" };
        break;
      default:
        userData = { name: credentials.username || "John Doe", role: "Maker", type: "user" };
    }
    
    setUser(userData);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setUser(null);
    setIsLoggedIn(false);
  };

  // First-time setup detection
  if (!setupCompleted) {
    return <SetupWizard onComplete={handleSetupComplete} />;
  }

  // Login screen
  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  // Main application
  return (
    <AccountingApp user={user!} onLogout={handleLogout} />
  );
};

export default Index;
