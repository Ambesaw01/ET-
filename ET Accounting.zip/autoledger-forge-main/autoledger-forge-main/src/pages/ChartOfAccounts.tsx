import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  ChevronDown, 
  ChevronRight,
  Calculator,
  Building,
  TrendingUp,
  TrendingDown,
  DollarSign
} from "lucide-react";

interface Account {
  id: string;
  number: string;
  name: string;
  type: "Asset" | "Liability" | "Equity" | "Revenue" | "Expense";
  category: string;
  normalBalance: "Debit" | "Credit";
  status: "Active" | "Inactive";
  balance: number;
  isParent?: boolean;
  children?: Account[];
}

const ChartOfAccounts = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<string[]>([
    "Current Assets", "Revenue", "Operating Expenses"
  ]);

  // Sample chart of accounts data
  const accounts: Account[] = [
    // Assets
    {
      id: "1",
      number: "1000",
      name: "Cash on Hand",
      type: "Asset",
      category: "Current Assets",
      normalBalance: "Debit",
      status: "Active",
      balance: 15420.50
    },
    {
      id: "2",
      number: "1010",
      name: "Cash in Bank - Primary",
      type: "Asset",
      category: "Current Assets",
      normalBalance: "Debit",
      status: "Active",
      balance: 45231.75
    },
    {
      id: "3",
      number: "1030",
      name: "Accounts Receivable",
      type: "Asset",
      category: "Current Assets",
      normalBalance: "Debit",
      status: "Active",
      balance: 12650.00
    },
    {
      id: "4",
      number: "1040",
      name: "Inventory",
      type: "Asset",
      category: "Current Assets",
      normalBalance: "Debit",
      status: "Active",
      balance: 8945.25
    },
    {
      id: "5",
      number: "1100",
      name: "Equipment",
      type: "Asset",
      category: "Fixed Assets",
      normalBalance: "Debit",
      status: "Active",
      balance: 25000.00
    },
    // Liabilities
    {
      id: "6",
      number: "2000",
      name: "Accounts Payable",
      type: "Liability",
      category: "Current Liabilities",
      normalBalance: "Credit",
      status: "Active",
      balance: 8750.00
    },
    {
      id: "7",
      number: "2020",
      name: "Accrued Expenses",
      type: "Liability",
      category: "Current Liabilities",
      normalBalance: "Credit",
      status: "Active",
      balance: 2340.50
    },
    // Equity
    {
      id: "8",
      number: "3000",
      name: "Owner's Capital",
      type: "Equity",
      category: "Owner's Equity",
      normalBalance: "Credit",
      status: "Active",
      balance: 50000.00
    },
    {
      id: "9",
      number: "3020",
      name: "Retained Earnings",
      type: "Equity",
      category: "Owner's Equity",
      normalBalance: "Credit",
      status: "Active",
      balance: 12774.67
    },
    // Revenue
    {
      id: "10",
      number: "4000",
      name: "Sales Revenue",
      type: "Revenue",
      category: "Revenue",
      normalBalance: "Credit",
      status: "Active",
      balance: 45231.45
    },
    {
      id: "11",
      number: "4010",
      name: "Service Revenue",
      type: "Revenue",
      category: "Revenue",
      normalBalance: "Credit",
      status: "Active",
      balance: 12500.00
    },
    // Expenses
    {
      id: "12",
      number: "5100",
      name: "Salaries and Wages",
      type: "Expense",
      category: "Operating Expenses",
      normalBalance: "Debit",
      status: "Active",
      balance: 18750.00
    },
    {
      id: "13",
      number: "5110",
      name: "Rent Expense",
      type: "Expense",
      category: "Operating Expenses",
      normalBalance: "Debit",
      status: "Active",
      balance: 6000.00
    },
    {
      id: "14",
      number: "5120",
      name: "Utilities Expense",
      type: "Expense",
      category: "Operating Expenses",
      normalBalance: "Debit",
      status: "Active",
      balance: 1250.75
    }
  ];

  const groupedAccounts = accounts.reduce((groups, account) => {
    const category = account.category;
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(account);
    return groups;
  }, {} as Record<string, Account[]>);

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "Asset": return <Building className="w-4 h-4 text-primary" />;
      case "Liability": return <TrendingDown className="w-4 h-4 text-destructive" />;
      case "Equity": return <DollarSign className="w-4 h-4 text-secondary" />;
      case "Revenue": return <TrendingUp className="w-4 h-4 text-success" />;
      case "Expense": return <TrendingDown className="w-4 h-4 text-warning" />;
      default: return <Calculator className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Asset": return "bg-primary/10 text-primary";
      case "Liability": return "bg-destructive/10 text-destructive";
      case "Equity": return "bg-secondary/10 text-secondary";
      case "Revenue": return "bg-success/10 text-success";
      case "Expense": return "bg-warning/10 text-warning";
      default: return "bg-muted/10 text-muted-foreground";
    }
  };

  const filteredAccounts = Object.entries(groupedAccounts).filter(([category, accounts]) =>
    category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    accounts.some(account => 
      account.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      account.number.includes(searchTerm)
    )
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Chart of Accounts</h1>
          <p className="text-muted-foreground">Manage your account structure and balances</p>
        </div>
        <Button className="bg-success hover:bg-success-light">
          <Plus className="w-4 h-4 mr-2" />
          Add Account
        </Button>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search accounts by name or number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              Export
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Accounts Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Account Listing
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredAccounts.map(([category, categoryAccounts]) => (
            <div key={category} className="mb-6">
              {/* Category Header */}
              <Button
                variant="ghost"
                onClick={() => toggleCategory(category)}
                className="w-full justify-start p-3 h-auto mb-2 bg-muted/50 hover:bg-muted"
              >
                {expandedCategories.includes(category) ? (
                  <ChevronDown className="w-4 h-4 mr-2" />
                ) : (
                  <ChevronRight className="w-4 h-4 mr-2" />
                )}
                <span className="font-semibold text-lg">{category}</span>
                <Badge variant="outline" className="ml-auto">
                  {categoryAccounts.length} accounts
                </Badge>
              </Button>

              {/* Category Accounts */}
              {expandedCategories.includes(category) && (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account #</TableHead>
                      <TableHead>Account Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Normal Balance</TableHead>
                      <TableHead className="text-right">Current Balance</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoryAccounts.map((account) => (
                      <TableRow key={account.id} className="hover:bg-muted/50">
                        <TableCell className="font-mono font-medium">
                          {account.number}
                        </TableCell>
                        <TableCell className="font-medium">
                          {account.name}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getTypeIcon(account.type)}
                            <Badge className={getTypeColor(account.type)}>
                              {account.type}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {account.normalBalance}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono">
                          ${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={account.status === "Active" ? "default" : "secondary"}
                            className={account.status === "Active" ? "bg-success" : ""}
                          >
                            {account.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center gap-2">
                            <Button variant="ghost" size="icon">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-destructive">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};

export default ChartOfAccounts;