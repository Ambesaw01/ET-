import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, Shield, UserCheck } from "lucide-react";

type LoginType = "user" | "admin" | "custom-admin";

interface LoginProps {
  onLogin: (type: LoginType, credentials: any) => void;
}

const Login = ({ onLogin }: LoginProps) => {
  const [loginType, setLoginType] = useState<LoginType>("user");
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
    pin: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(loginType, credentials);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-secondary flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-modal">
        <CardContent className="p-8">
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-8 h-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">EasyBooks Accounting</h1>
            <p className="text-muted-foreground mt-2">Secure access to your accounting system</p>
          </div>

          {/* Login Type Tabs */}
          <Tabs value={loginType} onValueChange={(value) => setLoginType(value as LoginType)} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="user" className="text-xs">
                <UserCheck className="w-4 h-4 mr-1" />
                User
              </TabsTrigger>
              <TabsTrigger value="admin" className="text-xs">
                <Shield className="w-4 h-4 mr-1" />
                Admin
              </TabsTrigger>
              <TabsTrigger value="custom-admin" className="text-xs">
                <Building2 className="w-4 h-4 mr-1" />
                Custom
              </TabsTrigger>
            </TabsList>

            <form onSubmit={handleSubmit} className="space-y-4">
              <TabsContent value="user" className="space-y-4 mt-0">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter your username"
                    value={credentials.username}
                    onChange={(e) => setCredentials(prev => ({ ...prev, username: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={credentials.password}
                    onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                    required
                  />
                </div>
              </TabsContent>

              <TabsContent value="admin" className="space-y-4 mt-0">
                <div className="space-y-2">
                  <Label htmlFor="pin">4-Digit PIN</Label>
                  <Input
                    id="pin"
                    type="password"
                    placeholder="Enter 4-digit PIN"
                    maxLength={4}
                    value={credentials.pin}
                    onChange={(e) => setCredentials(prev => ({ ...prev, pin: e.target.value }))}
                    required
                  />
                </div>
              </TabsContent>

              <TabsContent value="custom-admin" className="space-y-4 mt-0">
                <div className="space-y-2">
                  <Label htmlFor="admin-username">Admin Username</Label>
                  <Input
                    id="admin-username"
                    type="text"
                    placeholder="Enter admin username"
                    value={credentials.username}
                    onChange={(e) => setCredentials(prev => ({ ...prev, username: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-password">Admin Password</Label>
                  <Input
                    id="admin-password"
                    type="password"
                    placeholder="Enter admin password"
                    value={credentials.password}
                    onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                    required
                  />
                </div>
              </TabsContent>

              <Button type="submit" className="w-full bg-primary hover:bg-primary-hover">
                Sign In
              </Button>
            </form>

            <div className="mt-6 text-center">
              <a href="#" className="text-sm text-primary hover:underline">
                Forgot PIN/Password?
              </a>
            </div>
            </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;