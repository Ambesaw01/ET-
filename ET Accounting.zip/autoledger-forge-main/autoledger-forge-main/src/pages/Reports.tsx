import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Download, 
  Calendar, 
  Filter,
  TrendingUp,
  Calculator,
  Building,
  BarChart3,
  PieChart
} from "lucide-react";

const Reports = () => {
  const [selectedReport, setSelectedReport] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [showReport, setShowReport] = useState(false);

  const reportTypes = [
    { 
      id: "trial-balance", 
      name: "Trial Balance", 
      description: "All account balances at a specific date",
      icon: Calculator,
      category: "Financial"
    },
    { 
      id: "balance-sheet", 
      name: "Balance Sheet", 
      description: "Assets, Liabilities, and Equity statement",
      icon: Building,
      category: "Financial"
    },
    { 
      id: "income-statement", 
      name: "Income Statement", 
      description: "Revenue and expenses for a period",
      icon: TrendingUp,
      category: "Financial"
    },
    { 
      id: "general-ledger", 
      name: "General Ledger", 
      description: "Detailed account transactions",
      icon: FileText,
      category: "Detailed"
    },
    { 
      id: "journal-entries", 
      name: "Journal Entries", 
      description: "All journal entries for a period",
      icon: FileText,
      category: "Detailed"
    },
    { 
      id: "pending-transactions", 
      name: "Pending Transactions", 
      description: "Transactions awaiting approval",
      icon: Filter,
      category: "Workflow"
    },
    { 
      id: "user-activity", 
      name: "User Activity Report", 
      description: "Audit trail of user actions",
      icon: BarChart3,
      category: "System"
    }
  ];

  // Sample Trial Balance data
  const trialBalanceData = [
    { account: "1000", name: "Cash on Hand", debit: 15420.50, credit: 0 },
    { account: "1010", name: "Cash in Bank - Primary", debit: 45231.75, credit: 0 },
    { account: "1030", name: "Accounts Receivable", debit: 12650.00, credit: 0 },
    { account: "1040", name: "Inventory", debit: 8945.25, credit: 0 },
    { account: "1100", name: "Equipment", debit: 25000.00, credit: 0 },
    { account: "2000", name: "Accounts Payable", debit: 0, credit: 8750.00 },
    { account: "2020", name: "Accrued Expenses", debit: 0, credit: 2340.50 },
    { account: "3000", name: "Owner's Capital", debit: 0, credit: 50000.00 },
    { account: "3020", name: "Retained Earnings", debit: 0, credit: 12774.67 },
    { account: "4000", name: "Sales Revenue", debit: 0, credit: 45231.45 },
    { account: "4010", name: "Service Revenue", debit: 0, credit: 12500.00 },
    { account: "5100", name: "Salaries and Wages", debit: 18750.00, credit: 0 },
    { account: "5110", name: "Rent Expense", debit: 6000.00, credit: 0 },
    { account: "5120", name: "Utilities Expense", debit: 1250.75, credit: 0 }
  ];

  const totalDebits = trialBalanceData.reduce((sum, item) => sum + item.debit, 0);
  const totalCredits = trialBalanceData.reduce((sum, item) => sum + item.credit, 0);

  const generateReport = () => {
    if (selectedReport) {
      setShowReport(true);
    }
  };

  const groupedReports = reportTypes.reduce((groups, report) => {
    if (!groups[report.category]) {
      groups[report.category] = [];
    }
    groups[report.category].push(report);
    return groups;
  }, {} as Record<string, typeof reportTypes>);

  const renderTrialBalance = () => (
    <Card className="mt-6">
      <CardHeader className="bg-primary text-primary-foreground">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Trial Balance Report
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge className="bg-primary-foreground text-primary">
              As of: {new Date().toLocaleDateString()}
            </Badge>
            <Button variant="ghost" size="sm" className="text-primary-foreground border-primary-foreground">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="font-bold">Account #</TableHead>
              <TableHead className="font-bold">Account Name</TableHead>
              <TableHead className="font-bold text-right">Debit</TableHead>
              <TableHead className="font-bold text-right">Credit</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {trialBalanceData.map((item, index) => (
              <TableRow key={index} className="hover:bg-muted/50">
                <TableCell className="font-mono">{item.account}</TableCell>
                <TableCell className="font-medium">{item.name}</TableCell>
                <TableCell className="text-right font-mono">
                  {item.debit > 0 ? `$${item.debit.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '-'}
                </TableCell>
                <TableCell className="text-right font-mono">
                  {item.credit > 0 ? `$${item.credit.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '-'}
                </TableCell>
              </TableRow>
            ))}
            <TableRow className="border-t-2 font-bold bg-muted">
              <TableCell colSpan={2} className="text-right">TOTALS:</TableCell>
              <TableCell className="text-right font-mono">
                ${totalDebits.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </TableCell>
              <TableCell className="text-right font-mono">
                ${totalCredits.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
        
        <div className="p-4 bg-muted/50 border-t">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Badge variant={totalDebits === totalCredits ? "default" : "destructive"}>
                {totalDebits === totalCredits ? "Balanced" : "Out of Balance"}
              </Badge>
              <span className="text-sm text-muted-foreground">
                Difference: ${Math.abs(totalDebits - totalCredits).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="text-sm text-muted-foreground">
              Generated: {new Date().toLocaleString()}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Reports</h1>
          <p className="text-muted-foreground">Generate financial and system reports</p>
        </div>
      </div>

      {/* Report Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Select Report Type
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Report Types Grid */}
          {Object.entries(groupedReports).map(([category, reports]) => (
            <div key={category} className="space-y-3">
              <h3 className="font-semibold text-lg border-b pb-2">{category} Reports</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {reports.map((report) => (
                  <Card 
                    key={report.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedReport === report.id ? 'ring-2 ring-primary bg-primary/5' : ''
                    }`}
                    onClick={() => setSelectedReport(report.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded bg-primary/10">
                          <report.icon className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium">{report.name}</h4>
                          <p className="text-sm text-muted-foreground mt-1">{report.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Report Parameters */}
      {selectedReport && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Report Parameters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date-from">From Date</Label>
                <Input
                  id="date-from"
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="date-to">To Date</Label>
                <Input
                  id="date-to"
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="format">Export Format</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select format" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pdf">PDF</SelectItem>
                    <SelectItem value="excel">Excel</SelectItem>
                    <SelectItem value="csv">CSV</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end mt-6">
              <Button onClick={generateReport} className="bg-success hover:bg-success-light">
                <BarChart3 className="w-4 h-4 mr-2" />
                Generate Report
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Report Output */}
      {showReport && selectedReport === "trial-balance" && renderTrialBalance()}
    </div>
  );
};

export default Reports;